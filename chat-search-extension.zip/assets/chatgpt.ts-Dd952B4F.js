(function(){const e=()=>{console.log("[ChatSearch] ChatGPT page detected, notifying background"),chrome.runtime.sendMessage({type:"DETECT_CHATGPT_ACCOUNT"}).catch(t=>{console.warn("[ChatSearch] Failed to notify background:",t)})};document.readyState==="loading"?document.addEventListener("DOMContentLoaded",e):setTimeout(e,500);
})()
